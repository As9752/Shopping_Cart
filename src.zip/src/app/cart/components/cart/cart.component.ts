import { Component } from '@angular/core';
import { CartService } from '../../cart.service';
import { Product } from 'src/app/model/product';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent {
  cartItems: Product[] = [];
  cartTotal: number= 0;
  constructor(private cartSvc: CartService, private router: Router){}

  ngOnInit(){
    this.cartSvc.cart$.subscribe({
      next: (cart) => {
        this.cartItems = cart.items;
        this.cartTotal = cart.total;
      }
    });
  }

  onClick(){
    this.router.navigateByUrl('/add');
  }

}

