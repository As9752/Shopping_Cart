import { Component } from '@angular/core';
import { ActivatedRoute,ParamMap } from '@angular/router';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css']
})
export class ProductDetailComponent {
  constructor(private activedRoute: ActivatedRoute){}

  ngOnInit(){
    console.log(this.activedRoute.snapshot.paramMap.get('productId'));

    // this.activedRoute.paramMap.subscribe((param: ParamMap) => {
    //   console.log(param.get('productId'));
    // });
  }

}
